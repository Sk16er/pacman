from src.runner import GameRun

if __name__=='__main__':
    gr = GameRun()
    gr.main()